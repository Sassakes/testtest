class MAV_ctrlMapMain: MAV_ctrlMap
{
};