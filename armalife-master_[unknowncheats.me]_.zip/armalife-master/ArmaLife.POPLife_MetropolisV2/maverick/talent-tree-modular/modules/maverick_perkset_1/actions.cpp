class VehiclePurchased {
    expToAdd = 100;
	message = "Vehicle Purchased";
};

class ItemProcessed {
    expToAdd = 20;
	message = "Items Processed (20xp per item you processed)";
};

class VehicleLockpicked {
    expToAdd = 100;
	message = "Vehicle Lockpicked";
};

class VehicleImpounded {
    expToAdd = 50;
	message = "Impounded Vehicle";
};

class Suicide {
    expToAdd = 450;
	message = "For our brothers";
};

class buyHouse {
    expToAdd = 700;
	message = "Property Purchasing";
};

class playerJailed {
    expToAdd = 800;
	message = "Cleaning the streets";
};

class robshop {
    expToAdd = 350;
	message = "Armed Robbery";
};

class robbank {
    expToAdd = 1300;
	message = "Armed Bank Robbery";
};

class robevidence {
    expToAdd = 1500;
	message = "Evidence Locker Robbery";
};

class FixSafe {
    expToAdd = 1300;
	message = "Fixed the Safe!";
};

class relic {
    expToAdd = 2375;
	message = "Relic Quest Complete!";
};

class relic2 {
    expToAdd = 3900;
	message = "Relic Quest 2 Complete!";
};

class relic3 {
    expToAdd = 4500;
	message = "Relic Quest 3 Complete!";
};

class DMV {
    expToAdd = 300;
	message = "Drivers Test Passed";
};

class satellite {
    expToAdd = 3000;
	message = "Secrets of the depths!";
};

class santa {
    expToAdd = 300;
	message = "Merry Christmas!";
};

class PickupEvidence {
    expToAdd = 150;
	message = "Picked up Evidence";
};

class CPR {
    expToAdd = 150;
	message = "Picked up a brother!";
};

class Stabalize {
    expToAdd = 200;
	message = "Extended lifetime for someone!";
};

class Revive {
    expToAdd = 250;
	message = "Helped out the injured!";
};

class burglary {
    expToAdd = 350;
	message = "Burglary";
};

class playtime {
	expToAdd = 150;
	message = "Taking a slot!";
};