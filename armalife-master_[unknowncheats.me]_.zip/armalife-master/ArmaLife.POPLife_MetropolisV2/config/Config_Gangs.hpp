class CfgGangs
{
    class Member_Management
    {
        Needed_Rank_Invites = 3;
        Needed_Rank_Promote = 2;
        Needed_Rank_Demote = 3;
        Needed_Rank_Kick = 2;
        Needed_Rank_UseBank = 2;
        Needed_Rank_Freq = 1;
        Rank_Array[] = {"Recruit", "Member", "Senior Member", "Co-Owner", "Owner"};
    };
};