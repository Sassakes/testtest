class MAV_ctrlMenuStrip: MAV_ctrlMenu
{
	type = CT_MENU_STRIP;		
	colorStripBackground[] = {0,0,0,1};
	colorStripText[] = {COLOR_TEXT_RGBA};
	colorStripSelect[] = {0,0,0,1};
	colorStripSelectBackground[] = {COLOR_ACTIVE_RGBA};
	colorStripDisabled[] = {COLOR_TEXT_RGB,0.25};	
	
};