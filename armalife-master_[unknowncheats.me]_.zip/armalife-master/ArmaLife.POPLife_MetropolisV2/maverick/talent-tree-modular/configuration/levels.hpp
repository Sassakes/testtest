class Level_0 {
    displayName = "Rank 0";
    expRequired = 0;
    perkPointsOnUnlock = 2;
};

class Level_1 {
    displayName = "Rank 1";
    expRequired = 85;
    perkPointsOnUnlock = 2;
};

class Level_2 {
    displayName = "Rank 2";
    expRequired = 340;
    perkPointsOnUnlock = 2;
};

class Level_3 {
    displayName = "Rank 3";
    expRequired = 765;
    perkPointsOnUnlock = 2;
};

class Level_4 {
    displayName = "Rank 4";
    expRequired = 1360;
    perkPointsOnUnlock = 2;
};

class Level_5 {
    displayName = "Rank 5";
    expRequired = 2125;
    perkPointsOnUnlock = 3;
};

class Level_6 {
    displayName = "Rank 6";
    expRequired = 3060;
    perkPointsOnUnlock = 3;
};

class Level_7 {
    displayName = "Rank 7";
    expRequired = 4165;
    perkPointsOnUnlock = 3;
};

class Level_8 {
    displayName = "Rank 8";
    expRequired = 5440;
    perkPointsOnUnlock = 3;
};

class Level_9 {
    displayName = "Rank 9";
    expRequired = 6885;
    perkPointsOnUnlock = 3;
};

class Level_10 {
    displayName = "Rank 10";
    expRequired = 8500;
    perkPointsOnUnlock = 10;
};

class Level_11 {
    displayName = "Rank 11";
    expRequired = 10285;
    perkPointsOnUnlock = 3;
};

class Level_12 {
    displayName = "Rank 12";
    expRequired = 12240;
    perkPointsOnUnlock = 3;
};

class Level_13 {
    displayName = "Rank 13";
    expRequired = 14365;
    perkPointsOnUnlock = 3;
};

class Level_14 {
    displayName = "Rank 14";
    expRequired = 16660;
    perkPointsOnUnlock = 3;
};

class Level_15 {
    displayName = "Rank 15";
    expRequired = 19125;
    perkPointsOnUnlock = 3;
};

class Level_16 {
    displayName = "Rank 16";
    expRequired = 21760;
    perkPointsOnUnlock = 3;
};

class Level_17 {
    displayName = "Rank 17";
    expRequired = 24565;
    perkPointsOnUnlock = 3;
};

class Level_18 {
    displayName = "Rank 18";
    expRequired = 27540;
    perkPointsOnUnlock = 4;
};

class Level_19 {
    displayName = "Rank 19";
    expRequired = 30685;
    perkPointsOnUnlock = 4;
};

class Level_20 {
    displayName = "Rank 20";
    expRequired = 34000;
    perkPointsOnUnlock = 10;
};

class Level_21 {
    displayName = "Rank 21";
    expRequired = 37485;
    perkPointsOnUnlock = 4;
};

class Level_22 {
    displayName = "Rank 22";
    expRequired = 41140;
    perkPointsOnUnlock = 4;
};

class Level_23 {
    displayName = "Rank 23";
    expRequired = 44965;
    perkPointsOnUnlock = 4;
};

class Level_24 {
    displayName = "Rank 24";
    expRequired = 48960;
    perkPointsOnUnlock = 4;
};

class Level_25 {
    displayName = "Rank 25";
    expRequired = 53125;
    perkPointsOnUnlock = 4;
};

class Level_26 {
    displayName = "Rank 26";
    expRequired = 57460;
    perkPointsOnUnlock = 4;
};

class Level_27 {
    displayName = "Rank 27";
    expRequired = 61965;
    perkPointsOnUnlock = 4;
};

class Level_28 {
    displayName = "Rank 28";
    expRequired = 66640;
    perkPointsOnUnlock = 4;
};

class Level_29 {
    displayName = "Rank 29";
    expRequired = 71485;
    perkPointsOnUnlock = 4;
};

class Level_30 {
    displayName = "Rank 30";
    expRequired = 76500;
    perkPointsOnUnlock = 10;
};

class Level_31 {
    displayName = "Rank 31";
    expRequired = 81685;
    perkPointsOnUnlock = 4;
};

class Level_32 {
    displayName = "Rank 32";
    expRequired = 87040;
    perkPointsOnUnlock = 4;
};

class Level_33 {
    displayName = "Rank 33";
    expRequired = 92565;
    perkPointsOnUnlock = 4;
};

class Level_34 {
    displayName = "Rank 34";
    expRequired = 98260;
    perkPointsOnUnlock = 4;
};

class Level_35 {
    displayName = "Rank 35";
    expRequired = 104125;
    perkPointsOnUnlock = 4;
};

class Level_36 {
    displayName = "Rank 36";
    expRequired = 110160;
    perkPointsOnUnlock = 4;
};

class Level_37 {
    displayName = "Rank 37";
    expRequired = 116365;
    perkPointsOnUnlock = 4;
};

class Level_38 {
    displayName = "Rank 38";
    expRequired = 122740;
    perkPointsOnUnlock = 4;
};

class Level_39 {
    displayName = "Rank 39";
    expRequired = 129285;
    perkPointsOnUnlock = 4;
};

class Level_40 {
    displayName = "Rank 40";
    expRequired = 136000;
    perkPointsOnUnlock = 10;
};

class Level_41 {
    displayName = "Rank 41";
    expRequired = 142885;
    perkPointsOnUnlock = 4;
};

class Level_42 {
    displayName = "Rank 42";
    expRequired = 149940;
    perkPointsOnUnlock = 4;
};

class Level_43 {
    displayName = "Rank 43";
    expRequired = 157165;
    perkPointsOnUnlock = 4;
};

class Level_44 {
    displayName = "Rank 44";
    expRequired = 164560;
    perkPointsOnUnlock = 5;
};

class Level_45 {
    displayName = "Rank 45";
    expRequired = 172125;
    perkPointsOnUnlock = 5;
};

class Level_46 {
    displayName = "Rank 46";
    expRequired = 179860;
    perkPointsOnUnlock = 5;
};

class Level_47 {
    displayName = "Rank 47";
    expRequired = 187765;
    perkPointsOnUnlock = 5;
};

class Level_48 {
    displayName = "Rank 48";
    expRequired = 195840;
    perkPointsOnUnlock = 6;
};

class Level_49 {
    displayName = "Rank 49";
    expRequired = 204085;
    perkPointsOnUnlock = 6;
};

class Level_50 {
    displayName = "Rank 50";
    expRequired = 212500;
    perkPointsOnUnlock = 100;
};